
def compute_order_totals(items):
    total = 0.0
    for it in items:
        total += float(it.get("price",0.0)) * float(it.get("qty",1))
    return round(total, 2)
