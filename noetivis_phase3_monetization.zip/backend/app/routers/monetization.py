
from fastapi import APIRouter
from pydantic import BaseModel
from typing import Literal, Optional, Dict

router = APIRouter(prefix="/monetization", tags=["monetization"])

EventType = Literal["impression","click","conversion","order","refund"]

class MonetizationEvent(BaseModel):
    event_type: EventType
    source: str  # adsense_like, affiliate, ecommerce, dropship, reseller
    ref_id: str  # campaign_id / affiliate_id / order_id
    value: float = 0.0
    currency: str = "USD"
    metadata: Dict[str, str] = {}

@router.post("/event")
def record_event(evt: MonetizationEvent):
    # Simple commission rules for MVP
    if evt.source == "affiliate" and evt.event_type == "conversion":
        commission = evt.value * 0.15
    elif evt.source == "adsense_like" and evt.event_type == "click":
        commission = max(0.02, evt.value * 0.05)
    elif evt.source in ["ecommerce","dropship","reseller"] and evt.event_type == "order":
        commission = evt.value * 0.08
    else:
        commission = 0.0

    return {
        "event": evt.model_dump(),
        "platform_commission": round(commission, 6),
        "note": "Route this amount into Phase1 /ledger/record for split distribution."
    }
