
# Monetization System
- Ads: impression -> click -> conversion
- Affiliates: referral links -> conversions -> payouts
- Commerce: orders -> fulfillment -> resellers/dropship
All produces events that are valued and then written into the ledger.
