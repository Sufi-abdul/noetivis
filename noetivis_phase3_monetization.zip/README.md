
# Noetivis Phase 3 — Monetization (Ads + Affiliates + Commerce)

Adds:
- Ad network events (impression/click/conversion)
- Affiliate tracking (links, referrals, payouts)
- Commerce hooks (orders, items, dropship, reseller)
- Commission routing into the Phase 1 ledger split

Merge overlay into Phase 1 repo.
