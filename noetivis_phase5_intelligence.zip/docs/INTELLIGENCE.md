
# Intelligence Layer
- Signals (public/authorized)
- Sector agents
- Global intelligence index
- Entity graph utilities
