
# Noetivis Phase 5 — Intelligence (Agents + Index + Graph)

Adds:
- Signal ingestion (public/authorized sources)
- Sector agents (finance, education, gov, media, tech)
- Global Intelligence Index computation
- Entity graph expansion utilities

This is still MVP-safe (no scraping private data).
