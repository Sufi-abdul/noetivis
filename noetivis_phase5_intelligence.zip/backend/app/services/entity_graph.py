
import networkx as nx

class EntityGraph:
    def __init__(self):
        self.g = nx.Graph()

    def add_entity(self, eid: str, **meta):
        self.g.add_node(eid, **meta)

    def link(self, a: str, b: str, rel: str = "related"):
        self.g.add_edge(a, b, rel=rel)

    def to_json(self):
        return nx.node_link_data(self.g)
