
# Creator Economy (All Content Types)
Supports:
- Music: play, download, license
- Video: view, download, license
- Photo: view, download, license
- Writing: read, download, license

Next:
- Territory rates
- Platform-specific rules
- PRO registration & split sheets
