
# Noetivis Phase 2 — Creators & Royalties

Adds creator economy capabilities to Phase 1 Core:
- Content assets (music/video/photo/writing)
- Usage events (play/view/read/download/license)
- Royalty calculator (configurable rates)
- Payout schedule model
- API routes to register usage and compute royalties

How to use:
- Merge this folder into Phase 1 repo (overlay)
- Install backend requirements
- Run API and call /creators endpoints
