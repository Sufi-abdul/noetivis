
from fastapi import FastAPI
from routers import auth, entities, content, ledger

app = FastAPI(title="Noetivis Core", version="1.0")

app.include_router(auth.router)
app.include_router(entities.router)
app.include_router(content.router)
app.include_router(ledger.router)

@app.get("/health")
def health():
    return {"status": "Noetivis Core running"}
