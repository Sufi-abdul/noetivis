
from fastapi import APIRouter
router = APIRouter(prefix="/auth")

@router.post("/signup")
def signup(email: str):
    return {"status": "user created", "email": email}
