
# Noetivis Phase 1 — Core Platform

This phase contains the foundational infrastructure:

- Users
- Entities
- Content registry
- Royalty / commission ledger
- Database models
- FastAPI backend
- Commission logic (founder-root model)

This is the economic + identity core of Noetivis.
