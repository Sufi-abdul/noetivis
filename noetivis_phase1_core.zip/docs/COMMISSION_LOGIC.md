
# Commission Logic

Every value event is split automatically:

Founder: 20%
Contributors pool: 10%
Partner/referrer: 5%
Owner/creator: 65%

This ensures ecosystem growth + founder protection.
