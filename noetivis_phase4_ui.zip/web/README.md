
## Web Dashboard
Run (example):
- npm install
- npm run dev
