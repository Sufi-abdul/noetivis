
## Mobile Shell (React Native)
Scaffold placeholder — integrate with Expo or RN CLI.
