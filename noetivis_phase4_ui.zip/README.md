
# Noetivis Phase 4 — UI (Web + Mobile)

Includes:
- Modern responsive web dashboard (React)
- Futuristic styling (neon + dark)
- Pages: Overview, Earnings, Content, Ads/Affiliates
- Mobile shell (React Native) with nav-ready layout

This is a UI starter that calls API endpoints from Phase 1-3.
